<!DOCTYPE html>
<html>
  <body>
	<form method="post" action="putfeedback.php">
		SName<br>
		<input type="text" name="name">
		<br>
		time<br>
		<input type="text" name="time">
		<br>
		Address<br>
		<input type="text" name="address">
		<br><br>
		<input type="submit" name="save" value="submit">
	</form>
  </body>
</html>