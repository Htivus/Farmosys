<!DOCTYPE html>
<html>
  <body>
	<form method="post" action="putfeedback.php">
		Name<br>
		<input type="text" name="name">
		<br>
		phone<br>
		<input type="text" name="phone">
		<br>
		Company<br>
		<input type="text" name="company">
		<br><br>
		<input type="submit" name="save" value="submit">
	</form>
  </body>
</html>