<!DOCTYPE html>
<html>
  <body>
	<form method="post" action="putfeedback.php">
		Name<br>
		<input type="text" name="name">
		<br>
        location<br>
		<input type="text" name="location">
		<br>
		phone<br>
		<input type="text" name="phone">
		<br>
		<br>
		<input type="submit" name="save" value="submit">
	</form>
  </body>
</html>